"use strict";
(() => {
  // src/storage.ts
  var DEFAULT_BASE_URL = "https://denveler.com";
  async function getBaseUrl() {
    const { baseUrl } = await chrome.storage.sync.get({ baseUrl: DEFAULT_BASE_URL });
    return baseUrl.replace(/\/+$/, "");
  }
  async function setBaseUrl(url) {
    await chrome.storage.sync.set({ baseUrl: url.replace(/\/+$/, "") });
  }

  // src/options.ts
  var input = document.getElementById("baseUrl");
  var msg = document.getElementById("msg");
  getBaseUrl().then((url) => input.value = url);
  document.getElementById("save").addEventListener("click", async () => {
    let origin;
    try {
      origin = new URL(input.value).origin;
    } catch {
      msg.textContent = "URL inv\xE1lida.";
      return;
    }
    const granted = await chrome.permissions.request({ origins: [origin + "/*"] });
    if (!granted) {
      msg.textContent = "Permiso denegado para ese origen.";
      return;
    }
    await setBaseUrl(origin);
    msg.textContent = "Guardado \u2713";
  });
})();
