"use strict";
(() => {
  // src/api.ts
  async function request(base, path, init) {
    let res;
    try {
      res = await fetch(base.replace(/\/+$/, "") + path, {
        ...init,
        credentials: "include",
        headers: { "content-type": "application/json", ...init?.headers ?? {} }
      });
    } catch {
      return {
        ok: false,
        kind: "network",
        message: "No se pudo conectar con LaunchPad. \xBFEl servidor est\xE1 corriendo?"
      };
    }
    const body = await res.json().catch(() => null);
    if (res.ok) return { ok: true, data: body?.data };
    const kind = res.status === 401 ? "unauthorized" : res.status === 409 ? "duplicate" : res.status === 429 ? "rate_limited" : res.status === 400 ? "invalid" : "server";
    return { ok: false, kind, message: body?.error?.message ?? `Error ${res.status}` };
  }
  var getMyLinks = (base) => request(base, "/api/community-links?mine=1");
  var submitLink = (base, input) => request(base, "/api/community-links", {
    method: "POST",
    body: JSON.stringify(input)
  });
  async function postEvent(base, eventType) {
    try {
      await fetch(base.replace(/\/+$/, "") + "/api/extension/events", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ eventType })
      });
    } catch {
    }
  }

  // ../launchpad/src/lib/platforms.ts
  var PLATFORMS = [
    { id: "skool", label: "Skool", hosts: ["skool.com"] },
    { id: "discord", label: "Discord", hosts: ["discord.com"] },
    { id: "youtube", label: "YouTube", hosts: ["youtube.com", "youtu.be"] },
    { id: "x", label: "X", hosts: ["x.com", "twitter.com"] },
    { id: "facebook", label: "Facebook", hosts: ["facebook.com"] },
    { id: "linkedin", label: "LinkedIn", hosts: ["linkedin.com"] },
    { id: "instagram", label: "Instagram", hosts: ["instagram.com"] },
    { id: "telegram", label: "Telegram", hosts: ["t.me"] },
    { id: "circle", label: "Circle", hosts: ["circle.so"] }
  ];
  function hostMatches(hostname, allowed) {
    return hostname === allowed || hostname.endsWith("." + allowed);
  }
  function detectPlatform(raw) {
    try {
      const u = new URL(raw);
      if (u.protocol !== "https:") return null;
      for (const p of PLATFORMS) {
        if (p.hosts.some((h) => hostMatches(u.hostname, h))) return p.id;
      }
      return null;
    } catch {
      return null;
    }
  }

  // src/community.ts
  var RESERVED_FIRST_SEGMENTS = /* @__PURE__ */ new Set([
    "login",
    "signup",
    "signin",
    "pricing",
    "about",
    "legal",
    "privacy",
    "terms",
    "help",
    "support",
    "settings",
    "discovery"
  ]);
  function isCommunityPostUrl(raw) {
    if (detectPlatform(raw) === null) return false;
    try {
      const u = new URL(raw);
      const segs = u.pathname.split("/").filter(Boolean);
      if (segs.length === 0) return false;
      return !RESERVED_FIRST_SEGMENTS.has(segs[0].toLowerCase());
    } catch {
      return false;
    }
  }
  var LABEL_SUFFIX = new RegExp(
    `\\s*[|\\-\u2013\u2014]\\s*(${PLATFORMS.map((p) => p.label).join("|")})\\s*$`,
    "i"
  );
  function cleanTitle(raw) {
    let t = raw.replace(LABEL_SUFFIX, "").trim();
    if (t.length > 140) t = t.slice(0, 137).trimEnd() + "\u2026";
    return t;
  }

  // src/storage.ts
  var DEFAULT_BASE_URL = "http://localhost:3000";
  async function getBaseUrl() {
    const { baseUrl } = await chrome.storage.sync.get({ baseUrl: DEFAULT_BASE_URL });
    return baseUrl.replace(/\/+$/, "");
  }

  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  async function activeTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab?.url ? { url: tab.url, title: tab.title ?? "" } : null;
  }
  function switchTab(which) {
    $("view-send").hidden = which !== "send";
    $("view-links").hidden = which !== "links";
    $("tab-send").classList.toggle("active", which === "send");
    $("tab-links").classList.toggle("active", which === "links");
  }
  function showLogin(base) {
    const guard = $("send-guard");
    guard.hidden = false;
    $("guard-msg").textContent = "Necesitas iniciar sesi\xF3n en LaunchPad.";
    const btn = $("open-site");
    btn.hidden = false;
    btn.onclick = () => chrome.tabs.create({ url: base });
  }
  async function initSend(base) {
    const guard = $("send-guard");
    const guardMsg = $("guard-msg");
    const form = $("send-form");
    const tab = await activeTab();
    if (!tab || !isCommunityPostUrl(tab.url)) {
      guard.hidden = false;
      guardMsg.textContent = "Abre un post p\xFAblico de tu comunidad (Skool, Discord, YouTube, X, Facebook, LinkedIn, Instagram, Telegram o Circle) para enviarlo como logro.";
      return;
    }
    form.hidden = false;
    $("post-url").textContent = tab.url;
    $("title").value = cleanTitle(tab.title);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = $("submit");
      btn.disabled = true;
      $("send-msg").textContent = "Enviando\u2026";
      const result = await submitLink(base, {
        title: $("title").value.trim(),
        url: tab.url,
        type: $("type").value
      });
      if (result.ok) {
        $("send-msg").textContent = "\u2705 Enviado. Queda pendiente de verificaci\xF3n por un moderador.";
        void postEvent(base, "link_submitted");
      } else {
        const map = {
          unauthorized: "Inicia sesi\xF3n en LaunchPad y vuelve a intentar.",
          duplicate: "Ya enviaste este link antes.",
          rate_limited: "Demasiados env\xEDos por ahora. Intenta m\xE1s tarde.",
          invalid: result.message,
          network: result.message,
          server: "Error del servidor. Intenta m\xE1s tarde."
        };
        $("send-msg").textContent = "\u26A0\uFE0F " + map[result.kind];
        btn.disabled = false;
        if (result.kind === "unauthorized") showLogin(base);
      }
    });
  }
  async function initLinks(base) {
    const list = $("links-list");
    const msg = $("links-msg");
    msg.textContent = "Cargando\u2026";
    const result = await getMyLinks(base);
    if (!result.ok) {
      msg.textContent = result.kind === "unauthorized" ? "Inicia sesi\xF3n en LaunchPad para ver tus env\xEDos." : "\u26A0\uFE0F " + result.message;
      if (result.kind === "unauthorized") showLogin(base);
      return;
    }
    msg.textContent = result.data.length ? "" : "A\xFAn no enviaste ning\xFAn logro.";
    const STATUS_LABEL = { PENDING: "Pendiente", VERIFIED: "Verificado", REJECTED: "Rechazado" };
    for (const link of result.data) {
      const li = document.createElement("li");
      const title = document.createElement("span");
      title.textContent = link.title;
      const chip = document.createElement("span");
      chip.className = `chip ${link.status}`;
      chip.textContent = STATUS_LABEL[link.status];
      li.append(title, chip);
      list.append(li);
    }
  }
  (async function main() {
    const base = await getBaseUrl();
    void postEvent(base, "extension_opened");
    $("tab-send").addEventListener("click", () => switchTab("send"));
    $("tab-links").addEventListener("click", () => switchTab("links"));
    await initSend(base);
    await initLinks(base);
  })();
})();
